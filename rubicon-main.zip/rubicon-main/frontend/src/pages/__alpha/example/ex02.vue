<template>
  <v-app id="test-page">
    <v-main class="pa-0 ma-0">
    <v-toolbar color="#eeeeee" class="pl-5 pt-1" short elevation=0>
      <v-toolbar-title class="text-h6 font-weight-bold pb-1">
      EX 1
      </v-toolbar-title>
    </v-toolbar>
    <v-container fluid class="px-0 mt-0 pt-0">
    </v-container>
    </v-main>
  </v-app>
</template>

<script lang='ts'>
</script>

<style scoped>

</style>
