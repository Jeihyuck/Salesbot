from django.apps import AppConfig


class AlphaReverseProxyConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.alpha_reverse_proxy'
