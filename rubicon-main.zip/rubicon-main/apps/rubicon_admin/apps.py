from django.apps import AppConfig


class RubiconAdminConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.rubicon_admin'
    verbose_name = '201. Rubicon Admin'