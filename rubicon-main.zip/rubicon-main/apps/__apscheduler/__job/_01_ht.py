import logging

logger = logging.getLogger(__name__)

def eva_delta_T_forecast():
    print('##### Delta T Forecast #####')

    pass
