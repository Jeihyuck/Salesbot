import time
print(round(time.time()))