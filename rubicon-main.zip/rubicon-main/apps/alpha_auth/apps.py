from django.apps import AppConfig


class AlphaAuthConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.alpha_auth'
    verbose_name = '102. Alpha Auth'
