from django.apps import AppConfig


class RubiconDataConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.rubicon_data'
    verbose_name = '202. Rubicon Data'
