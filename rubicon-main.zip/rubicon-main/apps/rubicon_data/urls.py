# from django.urls import path
# from . import views
# from alpha.settings import VITE_OP_TYPE

# if VITE_OP_TYPE == 'PROD':
#     urlpatterns = []
# else:
#     urlpatterns = [
#         path('_test', views._test.as_view()),
#         path('product/', views.ProductView.as_view(), name='product'),
#         path('price/', views.PriceView.as_view(), name='price'),
#         path('productpivot/', views.ProductPivotView.as_view(), name='productpivot'),
#         path('productspecvalue/', views.ProductSpecValueView.as_view(), name='productspecvalue'),
#         path('dynamicfilter', views.DynamicFilterView.as_view(), name='dynamicfilter')
#     ]
