BRITISH_ENGLISH_INSTRUCTION = """- When "$Output Language$" is set to English:
  - Use British English exclusively (en-GB locale)
  - Apply British spelling conventions consistently
  - Use British vocabulary and terminology
  - Follow British grammatical patterns
  - Format dates as DD/MM/YYYY"""
