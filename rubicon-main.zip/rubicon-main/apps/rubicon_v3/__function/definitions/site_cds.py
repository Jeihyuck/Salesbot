# Auto-generated site_cds.py file (DEV environment - static constants)
# Generated on: 2025-07-29 12:19:40
# Do not modify this file directly - it will be overwritten

"""
Site code constants loaded from the database.
Usage:
    from apps.rubicon_v3.__function.definitions import site_cds
    print(site_cds.SOME_SITE_CD)
"""

B2C = 'B2C'
FN = 'FN'
# Hash: 9cc14323 (site_cd data fingerprint)