from django.apps import AppConfig


class AlphaWorkspaceConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.alpha_workspace'
